package ex1217;

interface OnClickListener {
	void onClick();
}

class MyOnClickListener implements OnClickListener {
	Window window;

	public MyOnClickListener(Window window) {
		this.window = window;
	}

	@Override
	public void onClick() {
		System.out.println(window.message);
	}
}

class Window {
	String message;
	OnClickListener listener;

	public Window(String message) {
		this.message = message;
	}

	public void setOnClickListener(OnClickListener listener) {
		this.listener = listener;
	}

	public void clickButton() {
		listener.onClick();
	}
}

public class Exam16 {
	public static void main(String[] args) {
		Window window = new Window("hello world");
		OnClickListener listener = new MyOnClickListener(window);
		window.setOnClickListener(listener);
		window.clickButton();
	}
}