package ex1217;

import java.util.ArrayList;
import java.util.List;

public class Exam07 {
public static List<Integer> toList(.......) {
	List<Integer> list = new ArrayList<Integer>();
	
}

	public static void main(String[] args) {
		System.out.println(toList(7));
		System.out.println(toList(2, 3, 5));
		System.out.println(toList(7, 3, 4, 5, 6));
	}
}