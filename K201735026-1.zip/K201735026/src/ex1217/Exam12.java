package ex1217;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Exam12 {
	public static String solution(List<String> list) {
	}

	public static void main(String[] args) {
		List<String> a1 = Arrays.asList("a", "a", "b", "a", "c", "d", "e", "b", "e");
		List<String> a2 = Arrays.asList("b", "a", "d", "a", "a", "b", "i", "b", "b");
		System.out.println(solution(a1));
		System.out.println(solution(a2));
	}
}